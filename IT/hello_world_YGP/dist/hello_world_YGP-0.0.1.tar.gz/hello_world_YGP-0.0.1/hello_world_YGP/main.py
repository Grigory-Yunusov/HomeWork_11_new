def greeting ():
    print("hello world!")