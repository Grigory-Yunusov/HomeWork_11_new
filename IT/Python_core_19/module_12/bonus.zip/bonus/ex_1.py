import shelve  # сховище файлів, https://ru.wikipedia.org/wiki/DBM
# shelve - дає можливість створювати базу даних у файлі.