"""
Качина типізація
Неявна типізація, латентна типізація або качина типізація (англ. Duck typing) в ООП мовах -
визначення факту реалізації певного інтерфейсу об'єктом без явної вказівки
або наслідування цього інтерфейсу, а просто реалізації повного набору методів.
"""


class Dog:
    def speak(self):
        return 'Woof'

class Cat:
    def speak(self):
        return 'Meow'

class Duck:
    def speak(self):
        return 'Quack'

def animal(animal):
    return animal.speak()

dog = Dog()
cat = Cat()
duck = Duck()

print(animal(dog))
print(animal(cat))
print(animal(duck))