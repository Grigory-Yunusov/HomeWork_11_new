class Duck:
    def swim_quack(self):
        print("I'm duck, and I can swim and quack")

class RobotDuck:
    def swim_quack(self):
        print("I'm robot duck, and I can swim and quack")

class Fish:
    def swim(self):
        print("I'm a fish, and I can swim but can't quack")


def animal(animal):
    return animal.swim_quack()

animal(Duck())
animal(RobotDuck())
animal(Fish())