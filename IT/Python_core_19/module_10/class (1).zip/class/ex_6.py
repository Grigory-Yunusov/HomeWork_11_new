"""
Method Resolution Order (MRO).
MRO в Python працює наступним чином:

1. Шукає атрибут серед атрибутів самого класу. Саме завдяки цьому ви можете "перевизначати"
батьківські атрибути.
2. Шукає атрибут у першого з батьків (той, що зазначено першим у списку батьків).
3. Шукає атрибут у наступного батька у списку батьків, доки такі є.
4. Шукає атрибут у батьках першого з батьків.
5. Повторює п.4 всім батьків.
6. Викликає виняток, що атрибут не знайдено.
"""

class A:
    def hi(self):
        print('A')

class B(A):
    def hi(self):
        print('B')

class C(A):
    def hi(self):
        print('C')

class D(B, C):
    def hi_(self):
        print(55)

d = D()
d.hi()
print(D.__mro__)


class Human:
    pass


class Developer(Human):
    field_description = "My Programming language"
    language = ""
    value = ''
    def make_some_code(self):
        return f"{self.field_description} is {self.value}"

    def test(self):
        return 25


class PythonDeveloper(Developer):
    value = "Python"

    def make_some_code(self):
        res = self.test()
        return f"{self.field_description} is {self.value}. Result is: {res}"


class JSDeveloper(Developer):
    value = "JavaScript"


a = PythonDeveloper()
print(a.make_some_code())

dev = Developer()
dev.value = 'Python'
print(dev.make_some_code())