"""
Асоціація
Це коли один клас включає інший клас як один з полів. Асоціація описується словом "має".
Тварина має господаря.

Виділяють два окремі випадки асоціації: композицію та агрегацію.

Композиція
Це коли господар не існує окремо від вихованця.
Він створюється при створенні вихованця і повністю управляється вихованцем.
"""

class Animal:
    def __init__(self, nickname, age):
        self.nickname = nickname
        self.age = age

    def get_info(self):
        return f"It's class Animal. Name is {self.nickname} and his age is: {self.age}"

class Owner:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone

    def info(self):
        return f'{self.name}- {self.phone}'

class Cat(Animal):
    def __init__(self, nickname, age, name, phone):
        super().__init__(nickname, age)
        self.owner = Owner(name, phone)  # композиція

    def get_info(self):
        return f"It's class Animal. Name is {self.nickname} and his age is: {self.age}"

    def sound(self):
        return f'{self.nickname} says Meow!!!!'

cat = Cat('Alex', 3, 'Petro', '0951234567')
print(cat.owner.info())