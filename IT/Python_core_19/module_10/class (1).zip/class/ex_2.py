"""
Базові принципи ООП - Спадкування

Спадкування є властивістю об'єктів породжувати своїх нащадків.
Об'єкт-нащадок автоматично успадковує від батька все:
поля та методи, може доповнювати об'єкти новими полями та змінювати (перекривати)
методи батька або доповнювати їх.
"""

class Animal:
    def __init__(self, nickname, age):
        self.nickname = nickname
        self.age = age

    def get_info(self):
        return f"It's class Animal. Name is {self.nickname} and his age is: {self.age}"

class Cat(Animal):
    name = ['Cat']     # mutable

    def __init__(self, nickname, age, owner):
        super().__init__(nickname, age)
        self.owner = owner

    def sound(self):
        return f'{self.nickname} says Meow!!!!'

    def get_info(self):
        return 5 * 5


cat = Cat('Borys', 3, 'Valerii')
print(cat.nickname)
print(cat.age)
cat.age = 6
print(cat.get_info())
print(cat.sound())

cat_2 = Cat('Jack', 2, 'Ivan')
print(f'cat.name: {cat.name}')

cat.name[0] = 'Test'

print(f'cat.name: {cat.name}')
print(f'cat_2.name: {cat_2.name}')
print(f'Cat.name: {Cat.name}')


class Car:
    brand = 'TOYOTA'

p1 = Car()
p2 = Car()
print(p1.brand)
print(p2.brand)

# Car.brand = 'Daewoo'
# print(p1.brand)
# print(p2.brand)
p1.brand = 'Mazda'
print(p1.brand)
print(p2.brand)

print(dir(cat))