class Animal:
    def __init__(self, nickname, age):
        self.nickname = nickname
        self.age = age

class Child(Animal):
    pass


cat = Child()
