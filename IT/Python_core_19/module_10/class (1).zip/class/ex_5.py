"""
Агрегація
Це коли екземпляр господаря створюється десь в іншому місці коду,
і передається в конструктор вихованця як параметр
"""


class Animal:
    def __init__(self, nickname, age):
        self.nickname = nickname
        self.age = age

    def get_info(self):
        return f"It's class Animal. Name is {self.nickname} and his age is: {self.age}"


class Owner:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone

    def info(self):
        return f'{self.name}- {self.phone}'


class Cat(Animal):
    def __init__(self, nickname, age, owner: Owner):
        super().__init__(nickname, age)
        self.owner = owner  # агрегація

    def get_info(self):
        return f"It's class Animal. Name is {self.nickname} and his age is: {self.age}"

    def sound(self):
        return f'{self.nickname} says Meow!!!!'


owner = Owner('Petro', '0951233455')
cat = Cat('Alex', 3, owner)
print(cat.owner.info())
