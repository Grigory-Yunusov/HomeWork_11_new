"""
Базові принципи ООП - Поліморфізм

Поліморфізм - це властивість споріднених об'єктів (тобто об'єктів, що мають одного спільного батька)
вирішувати схожі за змістом проблеми різними способами.
"""
class Animal:
    def __init__(self, nickname, age):
        self.nickname = nickname
        self.age = age

    def get_info(self):
        return f"It's class Animal. Name is {self.nickname} and his age is: {self.age}"


class Cat(Animal):
    def __init__(self, nickname, age, owner):
        super().__init__(nickname, age)
        self.owner = owner

    def sound(self):
        return f'{self.nickname} says Meow!!!!'

    def get_info(self):
        return f"It's class Animal. Name is {self.nickname} and his age is: {self.age}"


class Dog(Animal):
    def __init__(self, nickname, age, owner):
        super().__init__(nickname, age)
        self.owner = owner

    def sound(self):
        return f'{self.nickname} says Woof !!!!'

    def get_info(self):
        return f"It's class Animal. Name is {self.nickname} and his age is: {self.age}"

cat = Cat('Borys', 4, 'Ivan')
dog = Dog('Bella', 3, 'Petro')

print(isinstance(dog, Animal))
print(isinstance(dog, Cat))
print(isinstance(dog, Dog))
print('============')
print(type(dog) is Animal)
print(type(dog) is Dog)

for element in (cat, dog):
    print(element.sound())