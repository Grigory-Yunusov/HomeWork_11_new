class Animal:
    def __init__(self, nickname='', age=5):
        self.nickname = nickname
        self.age = age

    def get_info(self):
        return f"It's class Animal. Name is {self.nickname} and his age is: {self.age}"


animal = Animal()
print(animal.nickname)
print(animal.age)
print(animal.get_info())
animal.age = 5
print(animal.get_info())