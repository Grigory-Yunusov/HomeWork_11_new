class MyException(Exception):
    def __init__(self, x):
        self.x = x


def foo(number):
    if number < 0:
        raise MyException(f'Value is equal {number} and lower then 0')
    else:
        return "Hello world!"

try:
    print(foo(-100))
except MyException as e:
    print(e)

print(foo(-34))