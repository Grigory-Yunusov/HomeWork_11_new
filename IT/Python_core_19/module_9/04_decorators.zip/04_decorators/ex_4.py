# Зробити декоратор, який повертає кортеж з результатом функції обчислення факторіал та часом її виконання

from time import time, sleep

def time_counter_decorator(func):
    def interval(*args, **kwargs):
        start = time()
        result = func(*args, **kwargs)
        passed = time() - start
        return result, passed
    return interval

@time_counter_decorator
def caching_fibonacci(n):
    cache = {}
    sleep(2)

    def fibonacci(n):

        if n in cache:
            return cache[n]
        elif n <= 1:
            return n
        else:
            fibonachi_cache = fibonacci(n - 1) + fibonacci(n - 2)
            cache[n] = fibonachi_cache
            return fibonachi_cache

    return fibonacci(n)


f8 = caching_fibonacci(19)
print(f'f8: {f8}')

@time_counter_decorator
def test_func(x, y):
    sleep(3)
    return x * y

print(test_func(3, 5))