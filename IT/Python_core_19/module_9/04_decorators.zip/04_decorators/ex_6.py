# functools.wrap

import functools


def my_decorator(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        print('Before func is called!')
        res = func(*args, **kwargs)
        print('After func is called!')
        return res

    return wrapper

@my_decorator
def greeting(name):
    """
    This function is very important
    :arg: name: Str....
    :return: None
    """
    print(f'Hello: {name}')


greeting('Anton')


# print(greeting.__name__)
# print(greeting.__doc__)
print(help(greeting))

# wrapper
# None
# Help on function wrapper in module __main__:
#
# wrapper(*args, **kwargs)
#
# None
