# Приклад Декоратора без args, kwargs
def decorator_name(func):
    def wrapper(first_name, last_name):
        print('!' * 5)
        res = func(first_name, last_name)
        return res
    return wrapper


def prefix_decorator_name(func):
    def sonechko(first_name, last_name):
        print('prefix_decorator_name')
        return func(first_name, last_name)
    return sonechko


@decorator_name
@prefix_decorator_name
def full_name(first_name, last_name):
    print(f'Hello {first_name}, {last_name}')


@decorator_name
@prefix_decorator_name
def test_name(first_name, last_name):
    print(f'Hello {first_name}, {last_name}')


full_name('Ivan', 'Melnyk')
test_name('Olga', 'test')