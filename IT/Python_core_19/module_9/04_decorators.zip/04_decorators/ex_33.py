from ex_3 import greeting

greeting('Petro')