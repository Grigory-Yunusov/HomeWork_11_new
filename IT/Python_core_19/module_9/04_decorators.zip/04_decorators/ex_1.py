# Декоратори
# Шаблон проектування, який полягає в тому, щоб розширювати існуючий функціонал,
# не вносячи змін у код цього самого функціоналу.

def greeting(name):
    print(f'Hello, my name is: {name}')

# greeting('Alex')


def greeting_decorator(func):  # декоратор
    def wrapper(*args, **kwargs):
        print('Test')
        func(*args, **kwargs)  # викликаємо ф-цію (greeting)
        print('Bye, bye!!!')
    return wrapper


new_greeting = greeting_decorator(greeting)
new_greeting('Olga')
