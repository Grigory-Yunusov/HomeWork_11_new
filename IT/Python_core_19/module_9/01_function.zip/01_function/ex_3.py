# Функція як об'єкт першого класу
# Третя вимога - функція може бути повернена з функції як результат

def mul(a, b):
    return a * b


def sub(a, b):
    return a - b

def ops(operator: str):
    if operator == '*':
        return mul
    elif operator == '-':
        return sub
    else:
        pass

func_mul = ops('*')
res_mul = func_mul(2, 5)


func_sub = ops('-')
res_sub = func_sub(2, 5)

print(res_mul)
print(res_sub)