# Функція як об'єкт першого класу
# Друга вимога - Функція може бути передана в іншу функцію як аргумент
def mul(a, b):
    return a * b


def sub(a, b):
    return a - b


def oper(a, b, func):  # func - передаємо якусь ф-цію
    return func(a, b)


res_mul = oper(2, 3, mul)
print(res_mul)

res_sub = oper(2, 3, sub)
print(res_sub)
