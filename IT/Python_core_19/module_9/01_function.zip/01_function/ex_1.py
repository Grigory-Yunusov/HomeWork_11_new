# Функція як об'єкт першого класу
# Перша вимога - Функція може бути збережена у змінній чи структурі даних
def mul(a, b):
    return a * b

temp_value = mul  # зберегію функцію у змінній
result = temp_value(3, 5)  # викликаю функцію через змінну
print(temp_value)
print(result)

field = {
    'x': 2,
    'y': 3,
    'operation': temp_value
}

res = field.get('operation')(field.get('x'), field.get('y'))
print(res)
res_1 = field.get('operation')(2, 3)
print(res_1)