# Лямбда функція

def pow_normal(x):
    return x ** 2

pow_lambda = lambda x: x ** 2

print(pow_normal(5))
print(pow_lambda(5))