def taxer_simple(base_tax, money):
    if money >= 10000:
        base_tax = 2.5 * base_tax
    return money - base_tax * money


def taxer(base_tax):
    def calculate(money):
        nonlocal base_tax
        if money >= 10_000:
            base_tax = 2.5 * base_tax  # змінюємо базову ставку
        return money - base_tax * money

    return calculate


money_ukr_vasyl = taxer_simple(0.2, 5000)
money_ukr_iryna = taxer_simple(0.2, 5500)
money_ukr_olga = taxer_simple(0.2, 9000)
money_ukr_petro = taxer_simple(0.2, 9500)
money_swd = taxer_simple(0.3, 30000)

print(money_ukr_vasyl)
print(money_ukr_iryna)
print(money_ukr_olga)
print(money_ukr_petro)
print(money_swd)
