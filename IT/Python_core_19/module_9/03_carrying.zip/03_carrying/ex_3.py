from functools import partial


def greeting_simple(name, msg):
    return f'{name}: {msg}'


msg_anton = partial(greeting_simple, name='Anton')
print(msg_anton(msg='Go to Lesson'))
