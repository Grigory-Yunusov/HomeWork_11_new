# Closures

def taxer(base_tax):
    def calculate(money):
        nonlocal base_tax
        if money >= 10000:
            base_tax = 2 * base_tax  # змінюємо базову ставку
        return money - base_tax * money
    return calculate

ukr = taxer(0.1)  # %
nrw = taxer(0.45)  # %

money_ukr = ukr(9500)
money_nrw = nrw(25000)
print(money_ukr)
print(money_nrw)
