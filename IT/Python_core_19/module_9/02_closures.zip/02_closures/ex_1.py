# Замикання
# Особливість існування вкладених локальних просторів імен і той факт, що вони створюються динамічно,
# дає можливість використати механізм замикань у Python.


def greeting(name):  # зовнішня
    def message(message):  # внутрішня
        return f'{name}: {message}'
    return message  # повернення внутрішньої ф-ції (без виклику!!!)

message = greeting('Andrii')

print(message('Hello world!'))



