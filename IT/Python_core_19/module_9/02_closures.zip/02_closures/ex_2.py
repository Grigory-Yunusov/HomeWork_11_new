# Closures

def outer_function(x):  # зовнішня ф-ція
    y = 10  # ця змінна буде зберігатись в замиканні

    def inner_function():  # внутрішня ф-ція має доступ до змінної `х` з `outer_function`
        result = x + y
        print(f'Result is: {result}')

        def inner_inner_function():
            print(result)
        return inner_inner_function

    return inner_function  # повертаємо inner_function, яка є замиканням


closure = outer_function(5)# створюємо замикання, і передаємо 5 для х


closure()  # Викликаємо замикання