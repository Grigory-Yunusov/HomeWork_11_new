"""
Яку мінімальну кількість разів ви повинні підкинути монетку, щоб тричі поспіль
випав чи орел, чи решка?
random.randint(A, B) - випадкове ціле число N, A ≤ N ≤ B.
"""

import random

d = {
    1: 'Орел',
    2: 'Решка'
}
count_O = 0
count_P = 0
sequence = []

while True:
    trial = random.randint(1, 2)
    if trial == 1:
        count_O += 1
        count_P = 0
    else:
        count_P += 1
        count_O = 0
    sequence.append(d[trial])

    if count_O == 3 or count_P == 3:
        break

print(f"Sequence: {sequence}")
print(f"Sequence: {len(sequence)}")
if count_O == 3:
    print('Випало три орла')
else:
    print('Випало три решки')