import random
l = list(range(1, 40))
print(l)
random.shuffle(l)
print(l)

print(random.choice(l))
print(random.sample(l, 5))
print(random.sample('Hello world, nice to meet you', 5))