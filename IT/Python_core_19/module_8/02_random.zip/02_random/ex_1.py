import random

random.seed()
print(random.random())
print(random.randint(1, 10))

for _ in range(10):
    print(random.randrange(1, 10), end=" ")  # 4 7 8 5 8 8 3 1 7 4
    # print(random.randint(1, 10), end=' ')  # 1 1 10 5 9 9 3 5 7 5