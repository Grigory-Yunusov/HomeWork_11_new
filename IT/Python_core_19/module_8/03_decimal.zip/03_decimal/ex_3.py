# Створення Decimal із дійсних чисел

from decimal import Decimal

print(0.1 + 0.2)
print(Decimal(0.1) + Decimal(0.2))
print(Decimal(str(0.1)) + Decimal(str(0.2)))