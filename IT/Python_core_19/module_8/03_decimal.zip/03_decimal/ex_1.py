"""
Необхідність використання. Налаштування точності
"""

from decimal import Decimal, getcontext

f = 0.2 + 0.1 + 0.3 - 0.5
print(f)
result = Decimal('0.2') + Decimal('0.1') + Decimal('0.3') - Decimal('0.5')
print(result)
n = Decimal('1') / Decimal('3')
print(n)
print(type(n))
getcontext().prec = 6
n = Decimal('1') / Decimal('3')
print(n)
n = Decimal('100') / Decimal('3')
print(n)

