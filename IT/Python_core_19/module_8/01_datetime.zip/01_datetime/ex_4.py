# Timestamp
from datetime import datetime

d = datetime.now()
print(d.timestamp())